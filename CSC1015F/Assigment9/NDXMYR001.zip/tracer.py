# Tracer
# NDXMYR001
# Myrin Naidoo

def tracer(stri):
	strArr = []
	strArr.append("\"\"\"DEBUG\"\"\"\n")
	for line in stri:
		if line[:4] == "def ": 
			strArr.append(line+'\n')
			strArr.append("    \"\"\"DEBUG\"\"\";print(\'" + line.split(' ')[1][:line.split(' ')[1].find('(')] + "\')"+'\n')
		else: strArr.append(line+'\n')
	return strArr

def revTrace(stri):
	strArr = []
	for line in stri:
		if not("DEBUG" in line): strArr.append(line+"\n")
	return strArr
	
print("***** Program Trace Utility *****")
name = input("Enter the name of the program file: ")
try:
	file = open(name,'r')
except:
	print("Sorry, could not find file '" + name + "\'.")
	quit()
stri = file.read().split('\n')
file.close()

if stri[0] == "\"\"\"DEBUG\"\"\"":
	stri = revTrace(stri)
	print("Program contains trace statements")
	print("Removing...Done")
else:
	stri = tracer(stri)
	print("Inserting...Done")

file = open(name,'w')
file.writelines(stri)
file.close()
