#Prints ASCII Art rabbits
#Myrin Naidoo
#NDXMYR001 

print("(\\\               (\/)")
print("( '')    (\_/)   (.. )   //)")
print("O(\")(\") (\\'.'/) (\")(\")O (\" )")
print("        (\")_(\")        ()()o")