#include "HuffmanNode.h"
#include <memory>
#include <iostream>

using namespace std;

namespace SMTWAL002{

	HuffmanNode::HuffmanNode(char c, int i){
		this->left = NULL;
		this->right = NULL;

		value = i;
		letter = c;
	}

	HuffmanNode::HuffmanNode(const shared_ptr<HuffmanNode> &l, const shared_ptr<HuffmanNode> &r){
		this->left = l;
		this->right = r;
		value = this->left->value + this->right->value;
	}

	HuffmanNode::~HuffmanNode(){
		this->left  = nullptr;
		this->right = nullptr;
	}

	bool HuffmanNode::isLeaf(){
		if (this->left==NULL) return true;
		else return false;
	}

	HuffmanNode HuffmanNode::getLeft(){
		return *(this->left);
	}

	HuffmanNode HuffmanNode::getRight(){
		return *(this->right);
	}
}