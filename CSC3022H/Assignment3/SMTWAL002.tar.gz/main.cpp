#include "HuffmanTree.h"
#include <iostream>
#include <fstream>

using namespace std;
using namespace SMTWAL002;

int main(int argc, char *argv[]){
	HuffmanTree ht = HuffmanTree();
	ifstream input(argv[1]);

	//Build map
	cout << "Drawing map..." << endl;
	unordered_map<char, int> map;
	char c;
	while (input >> noskipws >> c){
		auto m = map.find(c);
		if (m == map.end()) map.insert({c,1});
		else{
			m->second = m->second +1;
		}
	}
	ht.BuildTree(map);

	//Reset file and read original text
	input.clear();
	input.seekg(0, ios::beg);
	string text((istreambuf_iterator<char>(input)), istreambuf_iterator<char>());
	input.close();

	//Write output text
	ofstream out(argv[2]);
	out << ht.Encode(text);
	out.close();

	//Write header
	ht.Header(string(argv[2]) + ".hdr");

	//Write compression ratio
	int output = ht.Encode(text).size();
	output = (output/8) + (output%8 ? 1 : 0);
	cout << "The compression ratio is: "<< text.size()/float(output) << endl;
}
