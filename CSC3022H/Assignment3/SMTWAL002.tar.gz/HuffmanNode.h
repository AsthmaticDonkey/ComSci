#ifndef HUFFMANNODE_H
#define HUFFMANNODE_H

#include <memory>

namespace SMTWAL002{
class HuffmanNode{
	private:
	std::shared_ptr<HuffmanNode> left;
	std::shared_ptr<HuffmanNode> right;

	public:
	int value;
	char letter;
	bool isLeaf();
	HuffmanNode getLeft();
	HuffmanNode getRight();
	HuffmanNode(char c, int i);
	HuffmanNode(const std::shared_ptr<HuffmanNode> &l, const std::shared_ptr<HuffmanNode> &r);
	~HuffmanNode();
};
}
#endif