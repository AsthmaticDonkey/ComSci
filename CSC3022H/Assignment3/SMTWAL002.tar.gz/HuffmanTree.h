#ifndef HUFFMANTREE_H
#define HUFFMANTREE_H

#include <queue>
#include <unordered_map>
#include <string>
#include <memory>
#include "HuffmanNode.h"

namespace SMTWAL002{
class HuffmanTree{
	private:
	void BuildCodeTable();
	void TraverseTree(HuffmanNode node, std::unordered_map<char, std::string> *ct, std::string& code);
	std::shared_ptr<HuffmanNode> root;
	std::unordered_map<char, std::string> codetable;

	public:
	HuffmanTree();
	~HuffmanTree();
	void BuildTree(std::unordered_map<char, int> map);
	std::string Encode(std::string text);
	void Header(std::string s);
};
}
#endif