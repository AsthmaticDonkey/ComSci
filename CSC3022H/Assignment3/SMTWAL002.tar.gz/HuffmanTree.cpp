#include "HuffmanTree.h"
#include "HuffmanNode.h"
#include <memory>
#include <iostream>
#include <fstream>

using namespace std;

namespace SMTWAL002{
	HuffmanTree::HuffmanTree(){
	}

	HuffmanTree::~HuffmanTree(){
		root = nullptr; //Destroys entire tree
	}

	//Comparison struct for HuffmanNode
	struct compare{
		bool operator()(const shared_ptr<HuffmanNode>& l, const shared_ptr<HuffmanNode>& r) const{
			return l->value > r->value;
  		}
	};

	void HuffmanTree::BuildCodeTable(){
		cout << "Constructing table..." << endl;
		string code = "";
		TraverseTree(*root,&codetable,code);
	}

	void HuffmanTree::TraverseTree(HuffmanNode node, std::unordered_map<char, std::string> *ct, string& code){
		// cout << "trav " << node.value << endl;
		if (node.isLeaf()){
			// cout << node.letter << " * " << node.value <<  "		<-- letter code --> " << code << endl;
			ct->insert({node.letter, code});
		}else{
			string leftcode  = code +"0";
			string rightcode = code +"1";

			TraverseTree(node.getLeft() ,ct, leftcode);
			TraverseTree(node.getRight(),ct, rightcode);
		}
	}

	void HuffmanTree::BuildTree(unordered_map<char, int> map){
		cout << "Growing tree..." << endl;
		//Make edge nodes
		//Is a vector the best datastructure to use?
		priority_queue<shared_ptr<HuffmanNode>, std::vector<shared_ptr<HuffmanNode>>, compare> q;
		for (auto it : map) q.push(make_shared<HuffmanNode>(it.first, it.second));

		//Construct tree
		while (q.size()>1){
			shared_ptr<HuffmanNode> r = q.top();
			q.pop();
			shared_ptr<HuffmanNode> l = q.top();
			q.pop();

			q.push(make_shared<HuffmanNode>(l,r));
		}
		root = q.top();
		BuildCodeTable();
	}

	void HuffmanTree::Header(string s){
		ofstream out(s);
		out << "Element size: " << codetable.size() << endl;
		for (auto it : codetable) out << it.first << "	: " << it.second << endl;
		out.close();
	}

	string HuffmanTree::Encode(string text){
		cout << "Encoding string..." << endl;
		string es;
		es.reserve(8*text.length());

		for (char& c : text){
			 auto m = codetable.find(c);
			 es.append(m->second);
		}

		return es;
	}
}